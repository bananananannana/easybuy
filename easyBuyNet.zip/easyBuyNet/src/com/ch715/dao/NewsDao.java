package com.ch715.dao;

public class NewsDao {

}
